/**
 * @authors Rachael Simmonds, Ethan Marschean, Alex Ketavongsa, 
 * Fernado Rodriguez, and Rouqi Chen 
 * @version 20190411
 * Prof. Patric
 * ISTE 121
**/

/* Imports */
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.activation.*;
import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMultipart;


       
public class SendEmailGUI extends JFrame implements ActionListener {
   //JLabels
   JLabel jlsenderEmail = new JLabel("Sender Email:");
   JLabel jlreceiverEmail = new JLabel("Receiver Email:");
   //Button
   JButton jbEmailSend = new JButton("Send Email");
   //Text Fields
   JTextField jtfSEmail = new JTextField(20);
   JTextField jtfREmail = new JTextField(20);
   //JPanels
   JPanel jpCent = new JPanel();
   
   public SendEmailGUI(){
      jpCent.setLayout(new FlowLayout());
      jtfSEmail.setText("iste121project@gmail.com");
      jtfSEmail.setEnabled(false);
      jpCent.add(jlsenderEmail);
      jpCent.add(jtfSEmail);
      jpCent.add(jlreceiverEmail);
      jpCent.add(jtfREmail);
      jpCent.add(jbEmailSend);
      add(jpCent, BorderLayout.CENTER);
      
      setSize(260,170);
      setDefaultCloseOperation(HIDE_ON_CLOSE);
      setTitle("From !Failure");
      setVisible(true);
      setLocationRelativeTo(null);
      jbEmailSend.addActionListener(this);
   }
   public void actionPerformed(ActionEvent ae) {
         
      if(jtfREmail.getText().contains("@") && jtfREmail.getText().contains(".com")){
         String receiverEmail = jtfREmail.getText();
         emailDoingMethod(receiverEmail);
         JFrame Sentframe = new JFrame();
         JOptionPane.showMessageDialog(Sentframe, "Email Sent.");
      }
      else{
         JFrame Errorframe = new JFrame();
         JOptionPane.showMessageDialog(Errorframe, "Please Enter a Vaild Email.");
      }
   }
      
   public void emailDoingMethod(String receiverEmail){
   
   /* Email account information */
      final String username = "iste121project@gmail.com";
      final String password = "tigers121";
      
      /* Email server information */
      Properties prop = new Properties();
      prop.put("mail.smtp.host", "smtp.gmail.com");
      prop.put("mail.smtp.port", "587");
      prop.put("mail.smtp.auth", "true");
      prop.put("mail.smtp.starttls.enable", "true");
   
      /* Get the session object */
      Session session = Session.getInstance(prop, 
         new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
               return new PasswordAuthentication(username, password);
            }
         });
     
      try {
      
         Message message = new MimeMessage(session);
         message.setFrom(new InternetAddress("from@gmail.com"));
         message.setRecipients(
                    Message.RecipientType.TO,
                    InternetAddress.parse((String)receiverEmail));
         System.out.println(receiverEmail);
            
         message.setSubject("Message from Team !Failure");
         message.setText("Hello,"
                    + "Here is your message. Thank you for using our program!");
                           
         JFileChooser jfc = new JFileChooser();
         int returnValue = jfc.showOpenDialog(null);
      // // // // // //switch statement on what it returns^^^^
         if(returnValue == JFileChooser.APPROVE_OPTION){
         
            Multipart multipart = new MimeMultipart();         
            MimeBodyPart messageBodyPart = new MimeBodyPart();
            DataSource sauce = new FileDataSource(jfc.getSelectedFile());
            messageBodyPart.setDataHandler(new DataHandler(sauce));
            messageBodyPart.setFileName(jfc.getSelectedFile().getName());
            multipart.addBodyPart(messageBodyPart);
            message.setContent(multipart);
         
            Transport.send(message);
            System.out.println("Done");
         }
         if(returnValue == JFileChooser.CANCEL_OPTION){
            Transport.send(message);
            System.out.println("Done");
         
         }
         if(returnValue == JFileChooser.ERROR_OPTION){
            JOptionPane.showMessageDialog(null, "There was an Error with the JFileChooser");
            setVisible(false);
         }
      
         
      } catch (MessagingException e) {
         e.printStackTrace();
      }
   }
} 
